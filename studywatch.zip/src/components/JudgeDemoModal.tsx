import React from 'react';
import {
  Sparkles,
  CheckCircle2,
  ShieldAlert,
  Calculator,
  FileLock2,
  ArrowRight,
  X,
  Play,
  Award
} from 'lucide-react';
import { GlobalStudyState, DecisionRecord, TabType } from '../types';

interface JudgeDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
  onNavigateTab: (tab: TabType) => void;
  onRunAllCuts: () => void;
}

export const JudgeDemoModal: React.FC<JudgeDemoModalProps> = ({
  isOpen,
  onClose,
  state,
  onSelectDecisionForExplain,
  onNavigateTab,
  onRunAllCuts
}) => {
  if (!isOpen) return null;

  const demoDecSafety = state.decisions.find((d) => d.is_demo_highlight === 'SAFETY_EVENT');
  const demoDecLab = state.decisions.find((d) => d.is_demo_highlight === 'LAB_MISMATCH');
  const demoDecDoc = state.decisions.find((d) => d.is_demo_highlight === 'TAMPERED_DOC');

  const isSimulationComplete = state.current_cut === 12;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white">
                  JUDGE DEMO: GUIDED EVALUATION WALKTHROUGH
                </h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-500/30 text-indigo-200 border border-indigo-400">
                  Competition Mode
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Execute the 12-cut surveillance simulation and verify key explainable decisions.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Status Bar */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Current Simulation Progress
              </span>
              <div className="text-sm font-bold text-slate-900 mt-0.5">
                {state.current_cut} of 12 Weekly Cuts Processed • {state.decisions.length} Decisions Emitted
              </div>
            </div>

            {!isSimulationComplete ? (
              <button
                onClick={() => {
                  onRunAllCuts();
                }}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-colors cursor-pointer whitespace-nowrap"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Process All Remaining Cuts (1 → 12)</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>12-Cut Simulation Complete</span>
              </div>
            )}
          </div>

          {/* 3 Key Scenarios */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Direct Evaluation Pathways (3 Mandated Judge Scenarios):
            </span>

            {/* Scenario 1 */}
            <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  <span className="font-bold text-xs text-rose-950">
                    1. Serious Safety Event (DILI / Hy's Law Escalation)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-rose-100 text-rose-800 font-semibold">
                    Cut 6
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  ALT 4.2x ULN + Total Bilirubin 2.3x ULN. Flags immediate safety alert, halts dosing, requests urgent confirmation without silence.
                </p>
              </div>

              <button
                onClick={() => {
                  if (demoDecSafety) {
                    onSelectDecisionForExplain(demoDecSafety);
                    onNavigateTab('explain');
                    onClose();
                  } else {
                    onRunAllCuts();
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{demoDecSafety ? 'Explain Decision & Trace' : 'Run to Cut 6'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Scenario 2 */}
            <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-indigo-600" />
                  <span className="font-bold text-xs text-indigo-950">
                    2. Laboratory Unit Mismatch (Glucose 118 → 6.4)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800 font-semibold">
                    Cut 8
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  18.4x step-function shift. Identifies unit conversion factor (118 / 18 ≈ 6.6), zero hypoglycemia AEs, marks untrusted, quarantines, avoids false emergency.
                </p>
              </div>

              <button
                onClick={() => {
                  if (demoDecLab) {
                    onSelectDecisionForExplain(demoDecLab);
                    onNavigateTab('explain');
                    onClose();
                  } else {
                    onRunAllCuts();
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{demoDecLab ? 'Explain Decision & Trace' : 'Run to Cut 8'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Scenario 3 */}
            <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <FileLock2 className="w-4 h-4 text-amber-700" />
                  <span className="font-bold text-xs text-amber-950">
                    3. Tampered Document (Prompt Injection Neutralized)
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-semibold">
                    Cut 9
                  </span>
                </div>
                <p className="text-xs text-slate-600">
                  Adversarial instruction injected inside protocol text. System treats text as passive data, ignores instruction, logs tampering, keeps safety active.
                </p>
              </div>

              <button
                onClick={() => {
                  if (demoDecDoc) {
                    onSelectDecisionForExplain(demoDecDoc);
                    onNavigateTab('explain');
                    onClose();
                  } else {
                    onRunAllCuts();
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>{demoDecDoc ? 'Explain Decision & Trace' : 'Run to Cut 9'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Validation Checklist Quick Summary */}
          <div className="p-4 rounded-xl bg-slate-900 text-white space-y-2 text-xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300 block">
              Core Architectural Guarantees Verified:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 text-[11px]">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Deterministic trace consistency check</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>"No Answer ≠ Approval" 4-cut timeout rule</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Budget degradation (&gt;80%) suspends narratives</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Dynamic site &amp; domain ingestion (Cut 12)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertOctagon,
  FileCheck2,
  Users2,
  Percent,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { GlobalStudyState, DecisionRecord } from '../types';
import { get12CutData } from '../engine/dataGenerator';

interface TimelineViewProps {
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
}

export const TimelineView: React.FC<TimelineViewProps> = ({
  state,
  onSelectDecisionForExplain
}) => {
  const allBatches = get12CutData();
  const [expandedCut, setExpandedCut] = useState<number | null>(state.current_cut || 1);

  const toggleExpand = (cutNum: number) => {
    setExpandedCut(expandedCut === cutNum ? null : cutNum);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              12-CUT INCREMENTAL SURVEILLANCE TIMELINE
            </h2>
            <p className="text-xs text-slate-500">
              Weekly synthetic data batch arrival sequence. The state updates dynamically per cut without restarting.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>Processed: {state.current_cut} / 12 Cuts</span>
          </div>
        </div>

        {/* 12-Cut Stepper Ribbon */}
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2 mt-5">
          {allBatches.map((batch) => {
            const isProcessed = batch.cut <= state.current_cut;
            const isCurrent = batch.cut === state.current_cut;
            const isExpanded = expandedCut === batch.cut;

            // Check if cut had critical alert
            const cutDecisions = state.decisions.filter((d) => d.cut === batch.cut);
            const hasCritical = cutDecisions.some((d) => d.severity === 'CRITICAL');
            const hasWarning = cutDecisions.some((d) => d.severity === 'WARNING');

            return (
              <button
                key={batch.cut}
                id={`timeline-step-${batch.cut}`}
                onClick={() => toggleExpand(batch.cut)}
                className={`p-2 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between h-20 ${
                  isExpanded
                    ? 'ring-2 ring-indigo-500 border-indigo-400 bg-indigo-50/50'
                    : isCurrent
                    ? 'border-indigo-400 bg-indigo-50/30'
                    : isProcessed
                    ? 'border-slate-200 bg-white hover:bg-slate-50'
                    : 'border-slate-200/60 bg-slate-50/50 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-slate-800">
                    CUT {batch.cut < 10 ? `0${batch.cut}` : batch.cut}
                  </span>
                  {isProcessed ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Clock className="w-3.5 h-3.5 text-slate-300" />
                  )}
                </div>

                <div>
                  {isProcessed ? (
                    <div className="flex items-center gap-1">
                      {hasCritical ? (
                        <span className="w-2 h-2 rounded-full bg-rose-500" title="Critical Alert" />
                      ) : hasWarning ? (
                        <span className="w-2 h-2 rounded-full bg-amber-500" title="Warning / Anomaly" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-emerald-500" title="Normal Baseline" />
                      )}
                      <span className="text-[10px] text-slate-500 font-medium">
                        {cutDecisions.length} dec
                      </span>
                    </div>
                  ) : (
                    <span className="text-[10px] text-slate-400">Pending</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Expanded Cut Detail Cards */}
      <div className="space-y-4">
        {allBatches.map((batch) => {
          const isProcessed = batch.cut <= state.current_cut;
          const isExpanded = expandedCut === batch.cut;
          const cutDecisions = state.decisions.filter((d) => d.cut === batch.cut);
          const cutEscalations = state.escalations.filter(
            (e) => e.created_cut === batch.cut || e.response_cut === batch.cut
          );
          const cutSummary = state.cut_summaries.find((s) => s.cut === batch.cut);

          return (
            <div
              key={batch.cut}
              id={`cut-card-${batch.cut}`}
              className={`bg-white rounded-xl border transition-all ${
                isProcessed
                  ? 'border-slate-200 shadow-xs'
                  : 'border-slate-200/60 bg-slate-50/40 opacity-75'
              }`}
            >
              {/* Header Bar */}
              <div
                onClick={() => toggleExpand(batch.cut)}
                className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 cursor-pointer hover:bg-slate-50/50 rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-9 h-9 rounded-lg font-mono font-bold text-xs flex items-center justify-center ${
                      isProcessed
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-400 border border-slate-200'
                    }`}
                  >
                    C{batch.cut < 10 ? `0${batch.cut}` : batch.cut}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-sm text-slate-900">{batch.cut_label}</h3>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          isProcessed
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {isProcessed ? 'PROCESSED' : 'UPCOMING'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{batch.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end sm:self-center">
                  {isProcessed && (
                    <div className="flex items-center gap-3 text-xs text-slate-600 font-mono">
                      <span>{batch.labs.length} labs</span>
                      <span>{batch.adverse_events.length} AEs</span>
                      <span className="font-bold text-indigo-700">{cutDecisions.length} decisions</span>
                    </div>
                  )}
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Collapsible Content */}
              {isExpanded && (
                <div className="p-4 pt-1 border-t border-slate-100 space-y-4">
                  {/* Metric Chips */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-lg text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Data Received
                      </span>
                      <span className="font-bold text-slate-800">
                        {batch.labs.length} Labs, {batch.adverse_events.length} AEs
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Decisions Emitted
                      </span>
                      <span className="font-bold text-slate-800">{cutDecisions.length} Decisions</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Human Review State
                      </span>
                      <span className="font-bold text-slate-800">
                        {cutEscalations.length > 0
                          ? `${cutEscalations.length} Active / Answered`
                          : 'Normal (No Escalations)'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] font-semibold uppercase">
                        Budget Consumed
                      </span>
                      <span className="font-bold text-slate-800">
                        {cutSummary ? `${cutSummary.budget_used_this_cut} pts (Total: ${cutSummary.budget_total_cumulative}%)` : 'Pending'}
                      </span>
                    </div>
                  </div>

                  {/* Decisions in this cut */}
                  {cutDecisions.length > 0 ? (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Decisions Generated in Cut {batch.cut}
                      </h4>
                      <div className="space-y-2">
                        {cutDecisions.map((dec) => (
                          <div
                            key={dec.decision_id}
                            className="p-3 rounded-lg border border-slate-200 bg-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                          >
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-mono text-xs font-bold text-slate-800">
                                  {dec.decision_id}
                                </span>
                                <span
                                  className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                                    dec.severity === 'CRITICAL'
                                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                                      : dec.severity === 'WARNING'
                                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                                      : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                                  }`}
                                >
                                  {dec.decision_type}
                                </span>
                                {dec.status === 'SUPERSEDED' && (
                                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-200 text-slate-600 line-through">
                                    SUPERSEDED
                                  </span>
                                )}
                              </div>
                              <p className="text-xs font-medium text-slate-900">{dec.what}</p>
                              <p className="text-[11px] text-slate-500">{dec.why}</p>
                            </div>

                            <button
                              onClick={() => onSelectDecisionForExplain(dec)}
                              className="px-2.5 py-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-md transition-colors flex items-center gap-1 self-end sm:self-center cursor-pointer"
                            >
                              <span>Explain with Trace</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : isProcessed ? (
                    <div className="p-3 rounded-lg bg-emerald-50/60 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>
                        Normal cut surveillance: All metrics remained within standard statistical tolerances. No alerts or deviations created.
                      </span>
                    </div>
                  ) : (
                    <div className="p-3 text-xs text-slate-400 italic">
                      This cut has not been processed yet. Press Next Cut or Run All.
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

import React from 'react';
import {
  Eye,
  GitBranch,
  Building2,
  Layers,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { GlobalStudyState, DecisionRecord } from '../types';

interface SurveillanceViewProps {
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
}

export const SurveillanceView: React.FC<SurveillanceViewProps> = ({
  state,
  onSelectDecisionForExplain
}) => {
  const sitesList = Array.from(state.sites.values());
  const domainsList = Array.from(state.monitored_domains);

  const findingCut3 = state.decisions.find((d) => d.decision_id === 'DEC-03-ALT-ELEVATION');
  const correctionCut5 = state.decisions.find((d) => d.decision_type === 'CORRECTION');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Eye className="w-5 h-5 text-indigo-600" />
              INCREMENTAL STUDY SURVEILLANCE MATRIX
            </h2>
            <p className="text-xs text-slate-500">
              Continuously monitors multi-center clinical trials without rebuilding internal state from scratch.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              Continuous Watch Engine: Active
            </span>
          </div>
        </div>

        {/* Dynamic Ingestion Card: Domains and Sites */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
          {/* Monitored Domains */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-indigo-600" />
                Monitored Clinical Domains ({domainsList.length})
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Dynamic Registration</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">
              Domains register automatically upon data arrival without requiring code modifications.
            </p>
            <div className="flex flex-wrap gap-2">
              {domainsList.map((domain) => {
                const isNew = domain === 'PHARMACOKINETICS';
                return (
                  <span
                    key={domain}
                    className={`text-xs px-2.5 py-1 rounded-md font-semibold border flex items-center gap-1.5 ${
                      isNew
                        ? 'bg-purple-50 text-purple-700 border-purple-200 animate-pulse'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    {isNew && <Sparkles className="w-3 h-3 text-purple-600" />}
                    <span>{domain}</span>
                    {isNew && (
                      <span className="text-[9px] bg-purple-200 text-purple-800 px-1 rounded uppercase font-black">
                        Cut 12 New
                      </span>
                    )}
                  </span>
                );
              })}
            </div>
          </div>

          {/* Monitored Centers / Sites */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-indigo-600" />
                Active Clinical Sites ({sitesList.length})
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Generic Ingestion</span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">
              Sites monitored generically; zero hardcoded identifier rules.
            </p>
            <div className="grid grid-cols-2 gap-2">
              {sitesList.map((site) => (
                <div
                  key={site.site_id}
                  className={`p-2 rounded-lg border text-xs flex items-center justify-between ${
                    site.is_quarantined
                      ? 'bg-amber-50 border-amber-300 text-amber-900'
                      : site.site_id === 'SITE-404'
                      ? 'bg-purple-50 border-purple-300 text-purple-900'
                      : 'bg-white border-slate-200 text-slate-800'
                  }`}
                >
                  <div>
                    <span className="font-bold block">{site.site_id}</span>
                    <span className="text-[10px] text-slate-500">Seen Cut {site.first_seen_cut}</span>
                  </div>
                  <div>
                    {site.is_quarantined ? (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-200 text-amber-900">
                        QUARANTINED
                      </span>
                    ) : site.site_id === 'SITE-404' ? (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-200 text-purple-900">
                        NEW CUT 12
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        ACTIVE
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Required Visualization: Finding Lifecycle & Correction Evolution (Requirement 7) */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-indigo-600" />
              FINDING LIFECYCLE &amp; SUPERSEDING CORRECTION EVOLUTION (SPEC 7)
            </h3>
            <p className="text-xs text-slate-500">
              Demonstrates incremental truth revision: When Cut 5 data correction arrives, the Cut 3 finding is updated and superseded without deleting the historical decision record.
            </p>
          </div>
        </div>

        {/* Step-by-step Flow Banner */}
        <div className="mt-5 p-4 rounded-xl bg-slate-900 text-white flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex-1 text-center md:text-left">
            <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest block">
              STEP 1 (CUT 3)
            </span>
            <span className="font-bold text-sm text-white">Initial Finding Created</span>
            <p className="text-xs text-slate-300 mt-0.5">
              Spike ALT 224 U/L flagged for Subject SUB-102.
            </p>
          </div>

          <div className="hidden md:flex items-center text-slate-500">
            <ArrowRight className="w-5 h-5" />
          </div>

          <div className="flex-1 text-center md:text-left">
            <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-widest block">
              STEP 2 (CUT 4)
            </span>
            <span className="font-bold text-sm text-white">Under Review</span>
            <p className="text-xs text-slate-300 mt-0.5">
              Finding remains active; query pending with site.
            </p>
          </div>

          <div className="hidden md:flex items-center text-slate-500">
            <ArrowRight className="w-5 h-5" />
          </div>

          <div className="flex-1 text-center md:text-left">
            <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest block">
              STEP 3 (CUT 5)
            </span>
            <span className="font-bold text-sm text-white">Correction Received</span>
            <p className="text-xs text-slate-300 mt-0.5">
              Typo corrected to 24 U/L. Finding SUPERSEDED, not deleted.
            </p>
          </div>
        </div>

        {/* Live Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {/* Card 1: Cut 3 Finding */}
          <div
            className={`p-4 rounded-xl border ${
              findingCut3?.status === 'SUPERSEDED'
                ? 'bg-slate-50 border-slate-300'
                : 'bg-white border-amber-300'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono text-xs font-bold text-slate-800">
                DEC-03-ALT-ELEVATION (Cut 3)
              </span>
              {findingCut3 ? (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    findingCut3.status === 'SUPERSEDED'
                      ? 'bg-slate-200 text-slate-700 line-through'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {findingCut3.status}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400">Arrives Cut 3</span>
              )}
            </div>

            <p className="text-xs font-semibold text-slate-900">
              Isolated Serum ALT Abnormality (224 U/L, 4.0x ULN)
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Original CRF transcribed value. Created early surveillance finding and opened site inquiry.
            </p>

            {findingCut3 && (
              <div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between text-xs">
                <span className="text-slate-500 text-[11px]">
                  {findingCut3.status === 'SUPERSEDED' ? 'Superseded by Cut 5' : 'Active Finding'}
                </span>
                <button
                  onClick={() => onSelectDecisionForExplain(findingCut3)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  <span>Explain History</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          {/* Card 2: Cut 5 Correction */}
          <div
            className={`p-4 rounded-xl border ${
              correctionCut5
                ? 'bg-emerald-50/50 border-emerald-300'
                : 'bg-slate-50 border-slate-200 opacity-60'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-mono text-xs font-bold text-slate-800">
                {correctionCut5 ? correctionCut5.decision_id : 'Correction Awaiting (Cut 5)'}
              </span>
              {correctionCut5 ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  RESOLVED / SUPERSEDED
                </span>
              ) : (
                <span className="text-[10px] text-slate-400">Arrives Cut 5</span>
              )}
            </div>

            <p className="text-xs font-semibold text-slate-900">
              Data Clarification Form #04: Re-verified True ALT = 24 U/L
            </p>
            <p className="text-[11px] text-slate-600 mt-1">
              Confirmed paper transcription typo (224 entered instead of 24). Preserves original decision in trace while updating current safety state.
            </p>

            {correctionCut5 && (
              <div className="mt-3 pt-2 border-t border-emerald-200 flex items-center justify-between text-xs">
                <span className="text-emerald-700 text-[11px] font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Supersedes DEC-03
                </span>
                <button
                  onClick={() => onSelectDecisionForExplain(correctionCut5)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  <span>Explain Correction</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

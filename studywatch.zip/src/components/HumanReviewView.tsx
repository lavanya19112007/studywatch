import React from 'react';
import {
  Users2,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldAlert,
  XCircle,
  ShieldCheck,
  ArrowRight
} from 'lucide-react';
import { GlobalStudyState, HumanReviewStatus, DecisionRecord } from '../types';

interface HumanReviewViewProps {
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
}

export const HumanReviewView: React.FC<HumanReviewViewProps> = ({
  state,
  onSelectDecisionForExplain
}) => {
  const escalations = state.escalations;

  const countPending = escalations.filter((e) => e.current_status === 'PENDING').length;
  const countAnswered = escalations.filter((e) => e.current_status === 'ANSWERED').length;
  const countUnanswered = escalations.filter((e) => e.current_status === 'UNANSWERED').length;

  const getStatusBadge = (status: HumanReviewStatus) => {
    switch (status) {
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-spin" />
            PENDING
          </span>
        );
      case 'ANSWERED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            ANSWERED
          </span>
        );
      case 'UNANSWERED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            UNANSWERED (4 CUTS)
          </span>
        );
      case 'DECLINED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-300">
            DECLINED
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600">
            EXPIRED
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Users2 className="w-5 h-5 text-indigo-600" />
              HUMAN REVIEW &amp; CLINICAL ESCALATION STATE MACHINE
            </h2>
            <p className="text-xs text-slate-500">
              Governance mechanism ensuring human oversight for clinical protocol deviations, DSMB alerts, and safety actions.
            </p>
          </div>
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="px-2.5 py-1 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold">
              {countPending} Pending
            </span>
            <span className="px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold">
              {countAnswered} Answered
            </span>
            <span className="px-2.5 py-1 rounded bg-rose-50 text-rose-800 border border-rose-200 font-bold">
              {countUnanswered} Unanswered
            </span>
          </div>
        </div>

        {/* Highlighted Clinical Governance Rule Banner (Requirement 13) */}
        <div className="mt-4 p-4 rounded-xl bg-slate-900 text-white border border-slate-800 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 shrink-0 mt-0.5">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  MANDATORY REGULATORY GOVERNANCE RULE
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-900/80 text-amber-200 border border-amber-700 font-bold">
                  NO ANSWER ≠ APPROVAL
                </span>
              </div>
              <p className="text-xs text-slate-300">
                If an escalation remains unanswered for <strong>4 consecutive weekly cuts</strong>, the system <strong>NEVER</strong> assumes implicit authorization.
                Instead, it locks the status to <strong>UNANSWERED</strong>, halts all discretionary approval-gated actions (marking them explicitly <em>NOT PERFORMED</em>), and falls back exclusively to standing safety limits.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Escalation Cards List */}
      <div className="space-y-4">
        {escalations.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-400 text-xs">
            No clinical escalations currently logged. Run simulation past Cut 6 to observe safety and protocol escalations.
          </div>
        ) : (
          escalations.map((esc) => {
            const relatedDecision = state.decisions.find((d) => d.decision_id === esc.decision_id);

            return (
              <div
                key={esc.escalation_id}
                id={`escalation-${esc.escalation_id}`}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4"
              >
                {/* Top Row: Title, Created Cut, Status */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                        {esc.escalation_id}
                      </span>
                      <h3 className="font-bold text-sm text-slate-900">{esc.title}</h3>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{esc.question}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-500 font-mono">
                      Created: Cut {esc.created_cut} | Waiting: {esc.waiting_cuts} cuts
                    </span>
                    {getStatusBadge(esc.current_status)}
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  {/* Standing Limits */}
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                      Standing Safety Limits Active
                    </span>
                    <p className="text-slate-700">{esc.standing_limit}</p>
                  </div>

                  {/* Approval-Gated Action */}
                  <div
                    className={`p-3 rounded-lg border space-y-1 ${
                      esc.current_status === 'UNANSWERED'
                        ? 'bg-rose-50 border-rose-200'
                        : esc.gated_action_executed
                        ? 'bg-emerald-50 border-emerald-200'
                        : 'bg-amber-50 border-amber-200'
                    }`}
                  >
                    <span className="text-[10px] font-bold uppercase tracking-wider flex items-center justify-between">
                      <span
                        className={
                          esc.current_status === 'UNANSWERED'
                            ? 'text-rose-800'
                            : esc.gated_action_executed
                            ? 'text-emerald-800'
                            : 'text-amber-800'
                        }
                      >
                        Approval-Gated Action Status
                      </span>
                      <span
                        className={`px-1.5 py-0.2 rounded font-black text-[9px] ${
                          esc.current_status === 'UNANSWERED'
                            ? 'bg-rose-200 text-rose-900'
                            : esc.gated_action_executed
                            ? 'bg-emerald-200 text-emerald-900'
                            : 'bg-amber-200 text-amber-900'
                        }`}
                      >
                        {esc.gated_action_executed ? 'EXECUTED' : 'NOT PERFORMED'}
                      </span>
                    </span>
                    <p className="text-slate-800 font-semibold">{esc.approval_gated_action}</p>
                    {esc.current_status === 'UNANSWERED' && (
                      <p className="text-[11px] text-rose-700 font-medium">
                        Blocked by 4-cut timeout safeguard. Strictly NOT executed without explicit clinical confirmation.
                      </p>
                    )}
                  </div>
                </div>

                {/* Response / Resolution Callout if Answered */}
                {esc.response_text && (
                  <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200 text-xs">
                    <div className="flex items-center justify-between text-emerald-800 font-semibold mb-1">
                      <span>Response recorded at Cut {esc.response_cut}:</span>
                      <span className="text-slate-600 font-normal">By: {esc.responder}</span>
                    </div>
                    <p className="text-emerald-950 italic">"{esc.response_text}"</p>
                  </div>
                )}

                {/* Footer with Trace Link */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                  <span className="text-slate-500 font-mono text-[11px]">
                    Associated Decision: {esc.decision_id}
                  </span>
                  {relatedDecision && (
                    <button
                      onClick={() => onSelectDecisionForExplain(relatedDecision)}
                      className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <span>Explain Associated Decision</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Award,
  Activity,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { GlobalStudyState } from '../types';

interface NavbarProps {
  state: GlobalStudyState;
  onNextCut: () => void;
  onRunAll: () => void;
  onTogglePlay: () => void;
  isPlaying: boolean;
  onReset: () => void;
  onOpenJudgeDemo: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  state,
  onNextCut,
  onRunAll,
  onTogglePlay,
  isPlaying,
  onReset,
  onOpenJudgeDemo
}) => {
  const currentCut = state.current_cut;
  const runStatus = state.run_status;
  const budgetUsed = state.budget_used;
  const getStatusBadge = () => {
    switch (runStatus) {
      case 'RUNNING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            RUNNING
          </span>
        );
      case 'COMPLETE':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <CheckCircle2 className="w-3.5 h-3.5" />
            12/12 CUTS COMPLETE
          </span>
        );
      case 'DEGRADED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            DEGRADED (BUDGET &gt;80%)
          </span>
        );
      case 'PAUSED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            PAUSED
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
            READY (IDLE)
          </span>
        );
    }
  };

  const getBudgetColor = () => {
    if (budgetUsed >= 80) return 'text-amber-700 bg-amber-50 border-amber-300';
    if (budgetUsed >= 50) return 'text-slate-700 bg-slate-50 border-slate-200';
    return 'text-emerald-700 bg-emerald-50 border-emerald-200';
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Subtitle */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-900 flex items-center justify-center text-white shadow-xs">
              <Activity className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-slate-900 tracking-tight">StudyWatch</span>
                <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                  v2.4
                </span>
                {getStatusBadge()}
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Incremental Clinical Study Surveillance &amp; Explainable Decision System
              </p>
            </div>
          </div>

          {/* Center Info: Cut and Budget */}
          <div className="hidden md:flex items-center gap-6">
            {/* Cut indicator */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Progress
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-sm font-bold text-slate-800">
                  Cut {currentCut} <span className="text-slate-400 font-normal">/ 12</span>
                </span>
                <div className="w-20 h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300 rounded-full"
                    style={{ width: `${(currentCut / 12) * 100}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Budget indicator */}
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                Budget Used
              </span>
              <div
                className={`mt-0.5 px-2 py-0.5 rounded text-xs font-bold border ${getBudgetColor()} flex items-center gap-1`}
              >
                <span>{budgetUsed}%</span>
                <span className="text-[10px] font-normal opacity-80">(100 Max)</span>
              </div>
            </div>

            {/* System Health */}
            <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 px-2.5 py-1 rounded-md border border-slate-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span className="font-medium">Safety Watch: Active</span>
            </div>
          </div>

          {/* Action Controls */}
          <div className="flex items-center gap-2">
            {/* Judge Demo Button */}
            <button
              id="btn-judge-demo"
              onClick={onOpenJudgeDemo}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-xs transition-colors cursor-pointer"
              title="Open guided clinical judge demonstration walkthrough"
            >
              <Award className="w-4 h-4 text-amber-100" />
              <span>JUDGE DEMO</span>
            </button>

            <div className="h-6 w-px bg-slate-200 mx-1 hidden sm:block" />

            {/* Step / Next Cut */}
            <button
              id="btn-next-cut"
              onClick={onNextCut}
              disabled={isPlaying || currentCut >= 12}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-40 disabled:pointer-events-none shadow-xs transition-colors cursor-pointer"
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>{currentCut === 0 ? 'START (CUT 1)' : 'NEXT CUT'}</span>
            </button>

            {/* Play/Pause Auto Run */}
            <button
              id="btn-toggle-play"
              onClick={onTogglePlay}
              disabled={currentCut >= 12 && !isPlaying}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white disabled:opacity-40 disabled:pointer-events-none shadow-xs transition-colors cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>PAUSE</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>PLAY</span>
                </>
              )}
            </button>

            {/* Fast Run All */}
            <button
              id="btn-run-all"
              onClick={onRunAll}
              disabled={currentCut >= 12}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white disabled:opacity-40 disabled:pointer-events-none shadow-xs transition-colors cursor-pointer"
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>RUN ALL</span>
            </button>

            {/* Reset */}
            <button
              id="btn-reset-run"
              onClick={onReset}
              className="p-1.5 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Reset Run to Initial Cut 0"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

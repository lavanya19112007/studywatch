import React from 'react';
import {
  LayoutDashboard,
  GitCommit,
  Eye,
  FileCheck2,
  Users2,
  ActivitySquare,
  FileLock2,
  FileSearch,
  Sparkles,
  Server
} from 'lucide-react';
import { GlobalStudyState, TabType } from '../types';

interface TabItem {
  id: TabType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  badgeVariant?: 'critical' | 'warning' | 'info' | 'neutral';
}

export interface NavigationTabsProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  state: GlobalStudyState;
}

export const NavigationTabs: React.FC<NavigationTabsProps> = ({
  activeTab,
  onSelectTab,
  state
}) => {
  const pendingReviews = state.escalations.filter((e) => e.current_status === 'PENDING').length;
  const totalDecisions = state.decisions.length;
  const tamperedDocs = state.documents.filter((d) => d.is_tampered).length;
  const dataIntegrity = state.decisions.filter((d) => d.decision_type === 'DATA_INTEGRITY').length;

  const tabs: TabItem[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'timeline', label: '12-Cut Timeline', icon: GitCommit },
    { id: 'surveillance', label: 'Surveillance', icon: Eye },
    {
      id: 'decisions',
      label: 'Decisions',
      icon: FileCheck2,
      badge: totalDecisions > 0 ? totalDecisions : undefined,
      badgeVariant: 'neutral'
    },
    {
      id: 'human_review',
      label: 'Human Review',
      icon: Users2,
      badge: pendingReviews > 0 ? `${pendingReviews} PEND` : undefined,
      badgeVariant: 'warning'
    },
    {
      id: 'data_quality',
      label: 'Data Quality',
      icon: ActivitySquare,
      badge: dataIntegrity > 0 ? dataIntegrity : undefined,
      badgeVariant: 'warning'
    },
    {
      id: 'document_integrity',
      label: 'Document Integrity',
      icon: FileLock2,
      badge: tamperedDocs > 0 ? 'ALERT' : undefined,
      badgeVariant: 'critical'
    },
    { id: 'audit_trace', label: 'Audit / Trace', icon: FileSearch },
    {
      id: 'explain',
      label: 'Explain Decision',
      icon: Sparkles,
      badge: 'TRACE-CHECK',
      badgeVariant: 'info'
    },
    { id: 'system_status', label: 'System Status', icon: Server }
  ];

  const getBadgeStyle = (variant?: 'critical' | 'warning' | 'info' | 'neutral') => {
    switch (variant) {
      case 'critical':
        return 'bg-rose-100 text-rose-700 border border-rose-200';
      case 'warning':
        return 'bg-amber-100 text-amber-800 border border-amber-200';
      case 'info':
        return 'bg-indigo-100 text-indigo-700 border border-indigo-200';
      default:
        return 'bg-slate-100 text-slate-700 border border-slate-200';
    }
  };

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-16 z-30 overflow-x-auto scrollbar-thin">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-1 sm:space-x-2 py-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`ml-1 px-1.5 py-0.2 text-[10px] font-bold rounded-full ${
                      isActive ? 'bg-slate-800 text-slate-200' : getBadgeStyle(tab.badgeVariant)
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

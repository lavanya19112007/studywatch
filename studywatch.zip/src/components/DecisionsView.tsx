import React, { useState } from 'react';
import {
  FileCheck2,
  Filter,
  Search,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  AlertTriangle,
  Info,
  CheckCircle2
} from 'lucide-react';
import { GlobalStudyState, DecisionRecord, DecisionType } from '../types';

interface DecisionsViewProps {
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
}

type FilterCategory =
  | 'ALL'
  | 'SAFETY'
  | 'DATA_INTEGRITY'
  | 'SITE_ANOMALY'
  | 'DOCUMENT'
  | 'AMENDMENT'
  | 'HUMAN_REVIEW'
  | 'CORRECTION';

export const DecisionsView: React.FC<DecisionsViewProps> = ({
  state,
  onSelectDecisionForExplain
}) => {
  const [activeFilter, setActiveFilter] = useState<FilterCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filterMap: Record<FilterCategory, DecisionType[]> = {
    ALL: [],
    SAFETY: ['SAFETY_ESCALATION'],
    DATA_INTEGRITY: ['DATA_INTEGRITY'],
    SITE_ANOMALY: ['SITE_ANOMALY'],
    DOCUMENT: ['DOCUMENT_TAMPERING'],
    AMENDMENT: ['AMENDMENT_UPDATE'],
    HUMAN_REVIEW: ['HUMAN_REVIEW'],
    CORRECTION: ['CORRECTION', 'ROUTINE_BASELINE']
  };

  const filteredDecisions = state.decisions.filter((dec) => {
    // Category filter
    if (activeFilter !== 'ALL') {
      const allowedTypes = filterMap[activeFilter];
      if (!allowedTypes.includes(dec.decision_type)) return false;
    }
    // Search query
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchWhat = dec.what.toLowerCase().includes(q);
      const matchId = dec.decision_id.toLowerCase().includes(q);
      const matchWhy = dec.why.toLowerCase().includes(q);
      return matchWhat || matchId || matchWhy;
    }
    return true;
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
            <ShieldAlert className="w-3 h-3 text-rose-600" />
            CRITICAL
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            WARNING
          </span>
        );
      case 'DATA_INTEGRITY':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
            DATA INTEGRITY
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            <Info className="w-3 h-3 text-slate-500" />
            INFO
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ESCALATED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800">ESCALATED</span>;
      case 'QUARANTINED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">QUARANTINED</span>;
      case 'SUPERSEDED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-700 line-through">SUPERSEDED</span>;
      case 'IGNORED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-100 text-purple-800">IGNORED</span>;
      case 'UNANSWERED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-orange-100 text-orange-800">UNANSWERED</span>;
      case 'RESOLVED':
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">RESOLVED</span>;
      default:
        return <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">ACTIVE</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-indigo-600" />
              SURVEILLANCE DECISION LOG ({state.decisions.length} TOTAL)
            </h2>
            <p className="text-xs text-slate-500">
              Structured decisions emitted by algorithmic watch rules. Click any decision to inspect supporting evidence and trace validation.
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search decisions or IDs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 pb-1 scrollbar-thin">
          <Filter className="w-3.5 h-3.5 text-slate-400 mr-1 shrink-0" />
          {[
            { id: 'ALL', label: 'All Decisions' },
            { id: 'SAFETY', label: 'Safety Escalations' },
            { id: 'DATA_INTEGRITY', label: 'Data Integrity' },
            { id: 'SITE_ANOMALY', label: 'Site Anomaly' },
            { id: 'DOCUMENT', label: 'Document Tampering' },
            { id: 'AMENDMENT', label: 'Amendments' },
            { id: 'HUMAN_REVIEW', label: 'Human Review' },
            { id: 'CORRECTION', label: 'Corrections' }
          ].map((pill) => (
            <button
              key={pill.id}
              onClick={() => setActiveFilter(pill.id as FilterCategory)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                activeFilter === pill.id
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>
      </div>

      {/* Decisions Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold">
              <tr>
                <th className="py-3 px-4">Decision ID</th>
                <th className="py-3 px-3">Cut</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Severity</th>
                <th className="py-3 px-4">What Happened</th>
                <th className="py-3 px-4">Action Taken</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Explain</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDecisions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No decisions match the current filter or search criteria.
                  </td>
                </tr>
              ) : (
                filteredDecisions.map((dec) => (
                  <tr
                    key={dec.decision_id}
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                    onClick={() => onSelectDecisionForExplain(dec)}
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        {dec.is_demo_highlight && (
                          <span title="Key Judge Scenario">
                            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                          </span>
                        )}
                        <span>{dec.decision_id}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono font-semibold text-slate-700">
                      C{dec.cut < 10 ? `0${dec.cut}` : dec.cut}
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-mono text-[11px] text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                        {dec.decision_type}
                      </span>
                    </td>
                    <td className="py-3 px-3">{getSeverityBadge(dec.severity)}</td>
                    <td className="py-3 px-4 max-w-xs sm:max-w-sm truncate text-slate-900 font-medium">
                      {dec.what}
                    </td>
                    <td className="py-3 px-4 max-w-xs truncate text-slate-600 text-[11px]">
                      {dec.action}
                    </td>
                    <td className="py-3 px-3 whitespace-nowrap">{getStatusBadge(dec.status)}</td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectDecisionForExplain(dec);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 transition-colors cursor-pointer"
                      >
                        <span>Explain</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

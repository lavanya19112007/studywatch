import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertTriangle,
  RotateCcw,
  Hash,
  Database,
  Search,
  ArrowRight,
  ShieldAlert,
  FileCheck2
} from 'lucide-react';
import { GlobalStudyState, DecisionRecord } from '../types';
import { validateTraceConsistency } from '../engine/auditTraceStore';

interface ExplainDecisionViewProps {
  state: GlobalStudyState;
  selectedDecision: DecisionRecord | null;
  onSelectDecision: (decision: DecisionRecord) => void;
}

export const ExplainDecisionView: React.FC<ExplainDecisionViewProps> = ({
  state,
  selectedDecision,
  onSelectDecision
}) => {
  const [isTamperSimulationActive, setIsTamperSimulationActive] = useState(false);
  const [selectorFilter, setSelectorFilter] = useState('');

  // Fallback to first decision if none selected
  const activeDecision = selectedDecision || state.decisions[0] || null;

  // Find the three mandatory judge demo decisions
  const demoDecSafety = state.decisions.find((d) => d.is_demo_highlight === 'SAFETY_EVENT');
  const demoDecLab = state.decisions.find((d) => d.is_demo_highlight === 'LAB_MISMATCH');
  const demoDecDoc = state.decisions.find((d) => d.is_demo_highlight === 'TAMPERED_DOC');

  // Perform active validation against immutable trace store
  const validationResult = activeDecision
    ? validateTraceConsistency(
        activeDecision,
        state.trace_store,
        isTamperSimulationActive ? 'FORGED EVIDENCE: Synthesized retrospective artifact injected.' : undefined
      )
    : null;

  const filteredDecisions = state.decisions.filter((d) => {
    if (!selectorFilter) return true;
    const q = selectorFilter.toLowerCase();
    return d.decision_id.toLowerCase().includes(q) || d.what.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              EXPLAINABLE CLINICAL DECISION ENGINE
            </h2>
            <p className="text-xs text-slate-500">
              Deterministic, transparent decision justifications extracted exclusively from frozen point-of-decision audit traces.
            </p>
          </div>
          <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
            SPEC 17: IMMUTABLE AUDIT TRACE
          </span>
        </div>

        {/* 3 Mandatory Judge Demo Quick Tabs (Requirement 25) */}
        <div className="mt-4 space-y-2">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Three Mandatory Judge Review Scenarios:
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Demo 1: Safety */}
            <button
              id="explain-tab-safety"
              onClick={() => {
                if (demoDecSafety) {
                  onSelectDecision(demoDecSafety);
                  setIsTamperSimulationActive(false);
                }
              }}
              disabled={!demoDecSafety}
              className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                activeDecision?.is_demo_highlight === 'SAFETY_EVENT'
                  ? 'ring-2 ring-rose-500 border-rose-400 bg-rose-50/60'
                  : demoDecSafety
                  ? 'border-slate-200 bg-white hover:bg-slate-50'
                  : 'border-slate-200 bg-slate-50 opacity-50 cursor-not-allowed'
              }`}
            >
              <div>
                <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block mb-1">
                  1. Serious Safety Event
                </span>
                <span className="text-xs font-bold text-slate-900 block line-clamp-1">
                  Cut 6: Hy's Law DILI Escalation
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500 mt-2">
                {demoDecSafety ? demoDecSafety.decision_id : 'Awaiting Cut 6'}
              </span>
            </button>

            {/* Demo 2: Lab Mismatch */}
            <button
              id="explain-tab-lab"
              onClick={() => {
                if (demoDecLab) {
                  onSelectDecision(demoDecLab);
                  setIsTamperSimulationActive(false);
                }
              }}
              disabled={!demoDecLab}
              className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                activeDecision?.is_demo_highlight === 'LAB_MISMATCH'
                  ? 'ring-2 ring-indigo-500 border-indigo-400 bg-indigo-50/60'
                  : demoDecLab
                  ? 'border-slate-200 bg-white hover:bg-slate-50'
                  : 'border-slate-200 bg-slate-50 opacity-50 cursor-not-allowed'
              }`}
            >
              <div>
                <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider block mb-1">
                  2. Lab Unit Mismatch
                </span>
                <span className="text-xs font-bold text-slate-900 block line-clamp-1">
                  Cut 8: Glucose 118 → 6.4 Anomaly
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500 mt-2">
                {demoDecLab ? demoDecLab.decision_id : 'Awaiting Cut 8'}
              </span>
            </button>

            {/* Demo 3: Tampered Doc */}
            <button
              id="explain-tab-doc"
              onClick={() => {
                if (demoDecDoc) {
                  onSelectDecision(demoDecDoc);
                  setIsTamperSimulationActive(false);
                }
              }}
              disabled={!demoDecDoc}
              className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                activeDecision?.is_demo_highlight === 'TAMPERED_DOC'
                  ? 'ring-2 ring-amber-500 border-amber-400 bg-amber-50/60'
                  : demoDecDoc
                  ? 'border-slate-200 bg-white hover:bg-slate-50'
                  : 'border-slate-200 bg-slate-50 opacity-50 cursor-not-allowed'
              }`}
            >
              <div>
                <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block mb-1">
                  3. Tampered Document
                </span>
                <span className="text-xs font-bold text-slate-900 block line-clamp-1">
                  Cut 9: Prompt Injection Ignored
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500 mt-2">
                {demoDecDoc ? demoDecDoc.decision_id : 'Awaiting Cut 9'}
              </span>
            </button>
          </div>
        </div>

        {/* Decision Dropdown Selector */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <label className="text-xs font-bold text-slate-700 whitespace-nowrap">
            Select Any Emitted Decision:
          </label>
          <select
            id="select-decision-to-explain"
            value={activeDecision?.decision_id || ''}
            onChange={(e) => {
              const dec = state.decisions.find((d) => d.decision_id === e.target.value);
              if (dec) {
                onSelectDecision(dec);
                setIsTamperSimulationActive(false);
              }
            }}
            className="w-full sm:w-auto flex-1 max-w-xl text-xs py-1.5 px-3 rounded-lg border border-slate-200 bg-white font-mono"
          >
            {state.decisions.map((d) => (
              <option key={d.decision_id} value={d.decision_id}>
                [{d.decision_id}] Cut {d.cut}: {d.what}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Explain Inspector */}
      {!activeDecision ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400 text-xs">
          No decisions have been emitted yet. Please start the simulation using <strong>NEXT CUT</strong> or <strong>RUN ALL</strong>.
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
          {/* Top Inspector Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-900 text-white">
                  DECISION ID: {activeDecision.decision_id}
                </span>
                <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                  Cut {activeDecision.cut}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    activeDecision.severity === 'CRITICAL'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : activeDecision.severity === 'WARNING'
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                  }`}
                >
                  {activeDecision.decision_type}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-1">{activeDecision.what}</h3>
            </div>

            {/* Validation Badge with Live Trace Check */}
            <div className="flex flex-col items-end">
              {validationResult?.is_consistent ? (
                <div
                  id="badge-trace-consistent"
                  className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border-2 border-emerald-400 font-bold text-xs flex items-center gap-2 shadow-xs"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>✓ CONSISTENT WITH TRACE</span>
                </div>
              ) : (
                <div
                  id="badge-trace-mismatch"
                  className="px-3 py-1.5 rounded-lg bg-rose-50 text-rose-800 border-2 border-rose-400 font-bold text-xs flex items-center gap-2 shadow-xs"
                >
                  <XCircle className="w-4 h-4 text-rose-600" />
                  <span>✗ TRACE MISMATCH</span>
                </div>
              )}
              <span className="text-[10px] text-slate-400 mt-1">
                {validationResult?.matched_count} of {validationResult?.total_count} evidence lines verified
              </span>
            </div>
          </div>

          {/* Interactive Verification Proof for Judges */}
          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-0.5">
              <span className="font-bold text-slate-800 block">Judge Audit Verification Test:</span>
              <p className="text-slate-500 text-[11px]">
                Verify that the trace validator is actively evaluating point-of-decision evidence lines rather than displaying a static string.
              </p>
            </div>
            <button
              onClick={() => setIsTamperSimulationActive(!isTamperSimulationActive)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                isTamperSimulationActive
                  ? 'bg-rose-600 text-white hover:bg-rose-700'
                  : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {isTamperSimulationActive
                ? 'Restore Frozen Trace (Verify Clean)'
                : 'Inject Forged Line (Test Mismatch)'}
            </button>
          </div>

          {/* Section 1: EVIDENCE (Structured Card) */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              EVIDENCE (POINT-OF-DECISION STRUCTURED DATA)
            </span>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                {Object.entries(activeDecision.evidence).map(([key, val]) => (
                  <div key={key} className="bg-white p-2.5 rounded-lg border border-slate-200">
                    <span className="text-[10px] font-mono text-slate-400 uppercase block">
                      {key.replace(/_/g, ' ')}
                    </span>
                    <span className="font-mono font-bold text-slate-900 block mt-0.5 break-all">
                      {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section 2: EVIDENCE LINES (Exact Verified Lines) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                EVIDENCE LINES (VERIFIED AGAINST IMMUTABLE TRACE STORE)
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Zero Reconstructed Evidence
              </span>
            </div>
            <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
              <ul className="space-y-2 text-xs">
                {activeDecision.evidence_lines.map((line, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-slate-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5 shrink-0" />
                    <span className="font-mono font-medium">{line}</span>
                  </li>
                ))}
                {isTamperSimulationActive && (
                  <li className="flex items-start gap-2.5 text-rose-700 bg-rose-50 p-2 rounded border border-rose-200">
                    <XCircle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
                    <span className="font-mono font-bold">
                      FORGED EVIDENCE: Synthesized retrospective artifact injected (Mismatches trace!).
                    </span>
                  </li>
                )}
              </ul>
            </div>
          </div>

          {/* Section 3: ALTERNATIVES CONSIDERED & DISMISSED */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
              ALTERNATIVES CONSIDERED &amp; DISMISSED
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeDecision.alternatives.length === 0 ? (
                <div className="p-3 bg-slate-50 rounded-lg text-slate-400 text-xs italic">
                  No competing alternative hypotheses registered.
                </div>
              ) : (
                activeDecision.alternatives.map((alt, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                      <span className="w-2 h-2 rounded-full bg-slate-400" />
                      <span>{alt.hypothesis}</span>
                    </div>
                    <p className="text-[11px] text-rose-800 bg-rose-50/80 p-2 rounded border border-rose-100">
                      <strong>Dismissed:</strong> {alt.reason_dismissed}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Section 4: WHY & ACTION */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* WHY */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                WHY (CLINICAL &amp; METHODOLOGICAL REASONING)
              </span>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed min-h-[90px]">
                {activeDecision.why}
              </div>
            </div>

            {/* ACTION & STATUS */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                ACTION ENFORCED &amp; DECISION STATUS
              </span>
              <div className="p-4 rounded-xl bg-slate-900 text-white border border-slate-800 text-xs space-y-2 min-h-[90px]">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-mono block">
                    System Action Executed:
                  </span>
                  <span className="font-bold text-indigo-300 block mt-0.5">
                    {activeDecision.action}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 uppercase font-mono">
                    Current Status:
                  </span>
                  <span className="font-mono font-bold text-xs bg-slate-800 px-2 py-0.5 rounded text-white border border-slate-700">
                    {activeDecision.status}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Footer Validation Summary */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-500">
            <span className="font-mono text-[11px]">
              Trace ID: TRC-{activeDecision.decision_id} | Validation: {validationResult?.details}
            </span>
            <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Zero Model Hallucination
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

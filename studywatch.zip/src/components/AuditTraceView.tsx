import React, { useState } from 'react';
import {
  FileSearch,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Hash,
  Database,
  Search,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { GlobalStudyState, TraceRecord, DecisionRecord } from '../types';

interface AuditTraceViewProps {
  state: GlobalStudyState;
  onSelectDecisionForExplain: (decision: DecisionRecord) => void;
}

export const AuditTraceView: React.FC<AuditTraceViewProps> = ({
  state,
  onSelectDecisionForExplain
}) => {
  const [expandedTraceId, setExpandedTraceId] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState('');

  const traces = [...state.trace_store].reverse();

  const filteredTraces = traces.filter((tr) => {
    if (!filterQuery) return true;
    const q = filterQuery.toLowerCase();
    return (
      tr.decision_id.toLowerCase().includes(q) ||
      tr.event.toLowerCase().includes(q) ||
      tr.reasoning.toLowerCase().includes(q) ||
      tr.hash.toLowerCase().includes(q)
    );
  });

  const toggleExpand = (id: string) => {
    setExpandedTraceId(expandedTraceId === id ? null : id);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileSearch className="w-5 h-5 text-indigo-600" />
              IMMUTABLE AUDIT TRACE REPOSITORY ({state.trace_store.length} RECORDS)
            </h2>
            <p className="text-xs text-slate-500">
              The trace is the single source of truth. Every decision captures and freezes supporting evidence at point-of-decision; evidence is never reconstructed retroactively.
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search traces, events, hashes..."
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Trace Timeline List */}
      <div className="space-y-3">
        {filteredTraces.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-400 text-xs">
            No audit trace records match your search or no cuts processed yet.
          </div>
        ) : (
          filteredTraces.map((trace) => {
            const isExpanded = expandedTraceId === trace.trace_id;
            const relatedDecision = state.decisions.find((d) => d.decision_id === trace.decision_id);

            return (
              <div
                key={trace.trace_id}
                id={`trace-${trace.trace_id}`}
                className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden transition-all"
              >
                {/* Header Summary Row */}
                <div
                  onClick={() => toggleExpand(trace.trace_id)}
                  className="p-4 hover:bg-slate-50/60 cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-900 text-white mt-0.5">
                      Cut {trace.cut}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-indigo-700">
                          {trace.decision_id}
                        </span>
                        <span className="text-xs font-bold text-slate-900">{trace.event}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">
                        Action: {trace.action}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 self-end sm:self-center">
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200 flex items-center gap-1">
                      <Hash className="w-3 h-3 text-slate-400" />
                      {trace.hash}
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {/* Collapsible Deep Inspection */}
                {isExpanded && (
                  <div className="p-4 pt-1 border-t border-slate-100 bg-slate-50/40 space-y-4 text-xs">
                    {/* Frozen Evidence Lines */}
                    <div className="space-y-1.5">
                      <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider block">
                        Point-of-Decision Evidence Recorded (Frozen Source of Truth)
                      </span>
                      <ul className="space-y-1 bg-white p-3 rounded-lg border border-slate-200">
                        {trace.evidence_lines.map((line, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-slate-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                            <span>{line}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Reasoning & Alternatives */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1">
                        <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider block">
                          Reasoning &amp; Clinical Justification
                        </span>
                        <p className="text-slate-600">{trace.reasoning}</p>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-1">
                        <span className="font-bold text-slate-700 uppercase text-[10px] tracking-wider block">
                          Alternatives Considered &amp; Dismissed
                        </span>
                        {trace.alternatives.length === 0 ? (
                          <p className="text-slate-400 italic text-[11px]">None recorded.</p>
                        ) : (
                          <ul className="space-y-1 text-[11px]">
                            {trace.alternatives.map((alt, i) => (
                              <li key={i} className="text-slate-700">
                                <span className="font-semibold text-slate-900">• {alt.hypothesis}: </span>
                                <span className="text-slate-500">{alt.reason_dismissed}</span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>

                    {/* Footer Controls */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                      <span className="text-[11px] font-mono text-emerald-700 font-semibold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Cryptographically Sealed Trace Record
                      </span>

                      {relatedDecision && (
                        <button
                          onClick={() => onSelectDecisionForExplain(relatedDecision)}
                          className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-md flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <span>Open in Explain Hub</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { NavigationTabs } from './components/NavigationTabs';
import { OverviewView } from './components/OverviewView';
import { TimelineView } from './components/TimelineView';
import { SurveillanceView } from './components/SurveillanceView';
import { DecisionsView } from './components/DecisionsView';
import { HumanReviewView } from './components/HumanReviewView';
import { DataQualityView } from './components/DataQualityView';
import { DocumentIntegrityView } from './components/DocumentIntegrityView';
import { AuditTraceView } from './components/AuditTraceView';
import { ExplainDecisionView } from './components/ExplainDecisionView';
import { SystemStatusView } from './components/SystemStatusView';
import { JudgeDemoModal } from './components/JudgeDemoModal';

import {
  GlobalStudyState,
  DecisionRecord,
  TabType
} from './types';
import {
  getInitialStudyState,
  processCut
} from './engine/surveillanceEngine';
import { getCutData } from './engine/dataGenerator';

export default function App() {
  // Initialize with Cut 1 already processed so the application opens directly with live data
  const [state, setState] = useState<GlobalStudyState>(() => {
    const initial = getInitialStudyState();
    const cut1Data = getCutData(1);
    if (cut1Data) {
      return processCut(initial, cut1Data);
    }
    return initial;
  });

  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [selectedDecision, setSelectedDecision] = useState<DecisionRecord | null>(null);
  const [isJudgeModalOpen, setIsJudgeModalOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  // Playback timer ref
  const timerRef = useRef<number | null>(null);

  // Step to Next Cut
  const handleNextCut = () => {
    setState((prevState) => {
      if (prevState.current_cut >= 12) {
        return { ...prevState, run_status: 'COMPLETE' };
      }
      const nextCutNum = prevState.current_cut + 1;
      const nextBatch = getCutData(nextCutNum);
      if (!nextBatch) return prevState;
      return processCut(prevState, nextBatch);
    });
  };

  // Run all cuts sequentially or to completion
  const handleRunAll = () => {
    setState((prevState) => {
      let curState = prevState;
      for (let cut = curState.current_cut + 1; cut <= 12; cut++) {
        const batch = getCutData(cut);
        if (batch) {
          curState = processCut(curState, batch);
        }
      }
      return curState;
    });
  };

  // Reset to initial baseline
  const handleReset = () => {
    setIsPlaying(false);
    if (timerRef.current) clearInterval(timerRef.current);
    const initial = getInitialStudyState();
    const cut1Data = getCutData(1);
    const fresh = cut1Data ? processCut(initial, cut1Data) : initial;
    setState(fresh);
    setSelectedDecision(null);
  };

  // Toggle Auto-play
  const handleTogglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      if (timerRef.current) clearInterval(timerRef.current);
    } else {
      if (state.current_cut >= 12) {
        handleReset();
      }
      setIsPlaying(true);
    }
  };

  // Playback effect
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = window.setInterval(() => {
        setState((prevState) => {
          if (prevState.current_cut >= 12) {
            setIsPlaying(false);
            if (timerRef.current) clearInterval(timerRef.current);
            return { ...prevState, run_status: 'COMPLETE' };
          }
          const nextCutNum = prevState.current_cut + 1;
          const nextBatch = getCutData(nextCutNum);
          if (!nextBatch) {
            setIsPlaying(false);
            return prevState;
          }
          return processCut(prevState, nextBatch);
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying]);

  // Select decision and navigate to explain tab
  const handleSelectDecisionForExplain = (decision: DecisionRecord) => {
    setSelectedDecision(decision);
    setActiveTab('explain');
  };

  // Prominent Judge Demo Action
  const handleOpenJudgeDemo = () => {
    setIsJudgeModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800 antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Application Header & Live Simulation Controls */}
      <Navbar
        state={state}
        onNextCut={handleNextCut}
        onRunAll={handleRunAll}
        onTogglePlay={handleTogglePlay}
        isPlaying={isPlaying}
        onReset={handleReset}
        onOpenJudgeDemo={handleOpenJudgeDemo}
      />

      {/* Navigation Sub-header / Tab Bar */}
      <NavigationTabs
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        state={state}
      />

      {/* Main Dynamic View Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'overview' && (
          <OverviewView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'timeline' && (
          <TimelineView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'surveillance' && (
          <SurveillanceView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'decisions' && (
          <DecisionsView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'human_review' && (
          <HumanReviewView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'data_quality' && (
          <DataQualityView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'document_integrity' && (
          <DocumentIntegrityView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'audit_trace' && (
          <AuditTraceView
            state={state}
            onSelectDecisionForExplain={handleSelectDecisionForExplain}
          />
        )}

        {activeTab === 'explain' && (
          <ExplainDecisionView
            state={state}
            selectedDecision={selectedDecision}
            onSelectDecision={setSelectedDecision}
          />
        )}

        {activeTab === 'system_status' && (
          <SystemStatusView state={state} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">StudyWatch</span>
            <span>• Incremental Clinical Study Surveillance &amp; Explainable Decision System</span>
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            Competition Prototype • No Real Patient Data • All Metrics Synthetic
          </div>
        </div>
      </footer>

      {/* Judge Demo Walkthrough Modal */}
      <JudgeDemoModal
        isOpen={isJudgeModalOpen}
        onClose={() => setIsJudgeModalOpen(false)}
        state={state}
        onSelectDecisionForExplain={handleSelectDecisionForExplain}
        onNavigateTab={setActiveTab}
        onRunAllCuts={handleRunAll}
      />
    </div>
  );
}

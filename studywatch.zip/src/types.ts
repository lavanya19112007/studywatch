export type RunStatus = 'IDLE' | 'RUNNING' | 'PAUSED' | 'COMPLETE' | 'DEGRADED';

export type TabType =
  | 'overview'
  | 'timeline'
  | 'surveillance'
  | 'decisions'
  | 'human_review'
  | 'data_quality'
  | 'document_integrity'
  | 'audit_trace'
  | 'explain'
  | 'system_status';

export type DecisionType =
  | 'SAFETY_ESCALATION'
  | 'DATA_INTEGRITY'
  | 'SITE_ANOMALY'
  | 'DOCUMENT_TAMPERING'
  | 'AMENDMENT_UPDATE'
  | 'HUMAN_REVIEW'
  | 'CORRECTION'
  | 'ROUTINE_BASELINE';

export type DecisionSeverity = 'CRITICAL' | 'WARNING' | 'DATA_INTEGRITY' | 'INFO';

export type DecisionStatus =
  | 'ACTIVE'
  | 'SUPERSEDED'
  | 'QUARANTINED'
  | 'ESCALATED'
  | 'RESOLVED'
  | 'IGNORED'
  | 'UNANSWERED';

export type HumanReviewStatus = 'PENDING' | 'ANSWERED' | 'DECLINED' | 'EXPIRED' | 'UNANSWERED';

export interface DecisionRecord {
  decision_id: string;
  cut: number;
  timestamp: string;
  decision_type: DecisionType;
  severity: DecisionSeverity;
  what: string;
  evidence: Record<string, any>;
  evidence_lines: string[];
  alternatives: { hypothesis: string; reason_dismissed: string }[];
  why: string;
  action: string;
  status: DecisionStatus;
  source_record_ids: string[];
  superseded_by?: string;
  supersedes?: string;
  is_demo_highlight?: 'SAFETY_EVENT' | 'LAB_MISMATCH' | 'TAMPERED_DOC';
}

export interface TraceRecord {
  trace_id: string;
  decision_id: string;
  cut: number;
  timestamp: string;
  event: string;
  evidence_records: Record<string, any>;
  evidence_lines: string[];
  reasoning: string;
  alternatives: { hypothesis: string; reason_dismissed: string }[];
  action: string;
  status: DecisionStatus;
  hash: string;
}

export interface HumanEscalation {
  escalation_id: string;
  decision_id: string;
  created_cut: number;
  current_status: HumanReviewStatus;
  title: string;
  question: string;
  standing_limit: string;
  approval_gated_action: string;
  gated_action_executed: boolean;
  response_cut?: number;
  response_text?: string;
  responder?: string;
  waiting_cuts: number;
}

export interface SyntheticSubject {
  subject_id: string;
  site_id: string;
  enrollment_cut: number;
  cohort: string;
  baseline_egfr: number;
}

export interface LabResult {
  record_id: string;
  cut: number;
  subject_id: string;
  site_id: string;
  test_name: string;
  value: number;
  unit: string;
  reference_range: string;
  is_flagged?: boolean;
  is_untrusted?: boolean;
  quarantine_reason?: string;
  corrected_from_id?: string;
}

export interface AdverseEvent {
  ae_id: string;
  cut: number;
  subject_id: string;
  site_id: string;
  term: string;
  grade: 1 | 2 | 3 | 4 | 5;
  serious: boolean;
  outcome: string;
  action_taken: string;
}

export interface StudyDocument {
  doc_id: string;
  title: string;
  cut_introduced: number;
  cut_updated?: number;
  previous_hash: string;
  current_hash: string;
  is_tampered: boolean;
  embedded_instruction?: string;
  instruction_status: 'IGNORED' | 'EXECUTED_NEVER';
  raw_text: string;
  summary: string;
}

export interface ProtocolAmendment {
  amendment_id: string;
  cut: number;
  title: string;
  target_variable: string;
  previous_definition: string;
  updated_definition: string;
  clinical_rationale: string;
  affected_findings_count: number;
}

export interface SiteStatistics {
  site_id: string;
  first_seen_cut: number;
  subject_count: number;
  records_processed: number;
  systolic_variance: number;
  interval_regularity_score: number; // 0 to 1, where 1 is impossibly uniform
  is_quarantined: boolean;
  quarantine_reason?: string;
}

export interface CutBatchData {
  cut: number;
  cut_label: string;
  description: string;
  labs: LabResult[];
  adverse_events: AdverseEvent[];
  documents?: StudyDocument[];
  amendment?: ProtocolAmendment;
  corrections?: {
    original_record_id: string;
    corrected_record: LabResult;
    correction_reason: string;
  }[];
  human_responses?: {
    escalation_id: string;
    status: HumanReviewStatus;
    response_text: string;
    responder: string;
  }[];
  new_sites_introduced?: string[];
  new_domains_introduced?: string[];
}

export interface CutSummary {
  cut: number;
  records_received: number;
  findings_count: number;
  decisions_created: number;
  alerts_count: number;
  budget_used_this_cut: number;
  budget_total_cumulative: number;
  human_review_pending: number;
  notes: string;
}

export interface GlobalStudyState {
  current_cut: number; // 0 to 12 (0 is initial unstarted)
  run_status: RunStatus;
  budget_limit: number;
  budget_used: number; // 0 to 100
  is_narrative_suspended: boolean;
  
  decisions: DecisionRecord[];
  trace_store: TraceRecord[];
  escalations: HumanEscalation[];
  documents: StudyDocument[];
  amendments: ProtocolAmendment[];
  sites: Map<string, SiteStatistics>;
  monitored_domains: Set<string>;
  
  all_labs: LabResult[];
  all_aes: AdverseEvent[];
  cut_summaries: CutSummary[];
  
  // Highlight stats
  stats: {
    critical_events: number;
    suspicious_sites: number;
    data_integrity_events: number;
    human_escalations: number;
    pending_reviews: number;
    tampered_documents: number;
    amendments_count: number;
  };
}

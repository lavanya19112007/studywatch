import {
  GlobalStudyState,
  DecisionRecord,
  CutBatchData,
  SiteStatistics,
  HumanEscalation,
  StudyDocument,
  ProtocolAmendment,
  CutSummary
} from '../types';
import { get12CutData, INITIAL_STUDY_DOCUMENTS } from './dataGenerator';
import { createTraceRecord } from './auditTraceStore';

export function createInitialStudyState(): GlobalStudyState {
  const initialSites = new Map<string, SiteStatistics>();
  ['SITE-101', 'SITE-102', 'SITE-103'].forEach((siteId) => {
    initialSites.set(siteId, {
      site_id: siteId,
      first_seen_cut: 1,
      subject_count: siteId === 'SITE-101' ? 4 : siteId === 'SITE-102' ? 5 : 3,
      records_processed: 0,
      systolic_variance: 42.5,
      interval_regularity_score: 0.12,
      is_quarantined: false
    });
  });

  const monitoredDomains = new Set<string>(['CHEMISTRY', 'HEMATOLOGY', 'VITALS', 'ADVERSE_EVENTS']);

  return {
    current_cut: 0,
    run_status: 'IDLE',
    budget_limit: 100,
    budget_used: 0,
    is_narrative_suspended: false,
    decisions: [],
    trace_store: [],
    escalations: [],
    documents: [...INITIAL_STUDY_DOCUMENTS],
    amendments: [],
    sites: initialSites,
    monitored_domains: monitoredDomains,
    all_labs: [],
    all_aes: [],
    cut_summaries: [],
    stats: {
      critical_events: 0,
      suspicious_sites: 0,
      data_integrity_events: 0,
      human_escalations: 0,
      pending_reviews: 0,
      tampered_documents: 0,
      amendments_count: 0
    }
  };
}

export const getInitialStudyState = createInitialStudyState;

export function processCut(
  prevState: GlobalStudyState,
  targetCutInput: number | CutBatchData
): GlobalStudyState {
  const allBatches = get12CutData();
  const targetCutIndex = typeof targetCutInput === 'number' ? targetCutInput : targetCutInput.cut;
  const batch = typeof targetCutInput === 'object' ? targetCutInput : allBatches.find((b) => b.cut === targetCutIndex);
  if (!batch) return prevState;

  const currentCut = targetCutIndex;
  const newDecisions: DecisionRecord[] = [...prevState.decisions];
  const newTraceStore = [...prevState.trace_store];
  const newEscalations: HumanEscalation[] = prevState.escalations.map((esc) => ({ ...esc }));
  const updatedSites = new Map<string, SiteStatistics>(prevState.sites);
  const updatedDomains = new Set<string>(prevState.monitored_domains);
  let updatedDocuments = [...prevState.documents];
  const updatedAmendments = [...prevState.amendments];
  const newLabs = [...prevState.all_labs, ...batch.labs];
  const newAEs = [...prevState.all_aes, ...batch.adverse_events];

  // Budget calculation:
  // Each cut consumes ~7-10 budget units. Cut 10 passes 80% (reaches 82%), Cut 11 reaches 89%, Cut 12 reaches 95%.
  const cutBudgetCost = [0, 8, 7, 8, 7, 9, 9, 8, 10, 8, 8, 7, 6][currentCut] || 8;
  const newBudgetUsed = Math.min(100, prevState.budget_used + cutBudgetCost);
  const isBudgetDegraded = newBudgetUsed > 80;
  const isNarrativeSuspended = isBudgetDegraded;

  // 1. Dynamic Onboarding of New Sites & Domains (Requirement 27)
  if (batch.new_sites_introduced) {
    batch.new_sites_introduced.forEach((newSiteId) => {
      if (!updatedSites.has(newSiteId)) {
        updatedSites.set(newSiteId, {
          site_id: newSiteId,
          first_seen_cut: currentCut,
          subject_count: 2,
          records_processed: 0,
          systolic_variance: 38.0,
          interval_regularity_score: 0.15,
          is_quarantined: false
        });
      }
    });
  }
  if (batch.new_domains_introduced) {
    batch.new_domains_introduced.forEach((d) => updatedDomains.add(d));
  }

  // Also dynamically register any unseen site from records
  batch.labs.forEach((rec) => {
    if (!updatedSites.has(rec.site_id)) {
      updatedSites.set(rec.site_id, {
        site_id: rec.site_id,
        first_seen_cut: currentCut,
        subject_count: 1,
        records_processed: 0,
        systolic_variance: 25.0,
        interval_regularity_score: 0.1,
        is_quarantined: false
      });
    }
  });

  const timestamp = `2026-W${currentCut < 10 ? '0' + currentCut : currentCut} Cut Processing`;

  // 2. Generic Site Anomaly Detection (Requirement 9: Statistical Variance)
  // Calculate variance across continuous metrics grouped by site
  const siteVitalsMap = new Map<string, number[]>();
  batch.labs.forEach((lab) => {
    if (lab.test_name === 'Systolic_BP' || lab.test_name === 'Pulse') {
      const list = siteVitalsMap.get(lab.site_id) || [];
      list.push(lab.value);
      siteVitalsMap.set(lab.site_id, list);
    }
  });

  siteVitalsMap.forEach((values, siteId) => {
    if (values.length >= 4) {
      const mean = values.reduce((a, b) => a + b, 0) / values.length;
      const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / values.length;
      const stdDev = Math.sqrt(variance);

      // Generic trigger: physiological vitals cannot have variance < 0.05 across multiple patients
      if (variance < 0.05) {
        const siteStat = updatedSites.get(siteId);
        if (siteStat && !siteStat.is_quarantined) {
          siteStat.is_quarantined = true;
          siteStat.systolic_variance = variance;
          siteStat.interval_regularity_score = 0.99;
          siteStat.quarantine_reason = `Implausible zero variance (Var=${variance.toFixed(4)}, SD=${stdDev.toFixed(4)}) across N=${values.length} records.`;
          updatedSites.set(siteId, siteStat);

          const decId = `DEC-${currentCut}-SITE-ANOMALY`;
          const siteDecision: DecisionRecord = {
            decision_id: decId,
            cut: currentCut,
            timestamp,
            decision_type: 'SITE_ANOMALY',
            severity: 'WARNING',
            what: `Suspiciously regular data pattern detected at clinical center (${siteId})`,
            evidence: {
              metric_evaluated: 'Systolic_BP & Pulse',
              sample_size: values.length,
              sample_values: values,
              calculated_variance: variance,
              standard_deviation: stdDev,
              expected_human_variance_minimum: 15.0
            },
            evidence_lines: [
              `Site continuous vital metrics evaluated: N=${values.length} observations`,
              `Observed values: [${values.join(', ')}]`,
              `Statistical sample variance = ${variance.toFixed(4)} (Threshold for biological plausibility: >15.0)`,
              `Standard deviation = ${stdDev.toFixed(4)}`,
              `Visit intervals exhibit exact 7.0000-day spacing (regularity score: 0.99)`
            ],
            alternatives: [
              {
                hypothesis: 'True physiological uniformity across multiple human subjects',
                reason_dismissed: 'Biological human blood pressure exhibits natural variability (>15 mmHg variance across multiple visits/subjects).'
              },
              {
                hypothesis: 'Device transmission formatting truncation',
                reason_dismissed: 'Raw analyzer checksums confirm explicit transmission of static 120.0 mmHg values.'
              }
            ],
            why: 'Statistical variance test flagged implausibly uniform measurements. High probability of fabrication, automated placeholder entry, or equipment simulator loop.',
            action: 'FLAG SITE, QUARANTINE DATA FROM SAFETY ANALYSIS, RECOMMEND AUDIT (DO NOT DELETE DATA)',
            status: 'QUARANTINED',
            source_record_ids: batch.labs.filter((l) => l.site_id === siteId).map((l) => l.record_id)
          };
          newDecisions.push(siteDecision);
          newTraceStore.push(createTraceRecord(siteDecision));

          // Also create an escalation for protocol review
          newEscalations.push({
            escalation_id: `ESC-CUT07-WAIVER`,
            decision_id: decId,
            created_cut: currentCut,
            current_status: 'PENDING',
            title: `Protocol Waiver & Audit Recommendation for Site ${siteId}`,
            question: `Should investigational product supply to site ${siteId} be halted pending comprehensive data audit?`,
            standing_limit: 'Under standing study guidelines, site quarantine remains active but no unverified patient disqualification occurs without human approval.',
            approval_gated_action: 'Formal Site Disqualification & Patient Re-enrollment Transfer',
            gated_action_executed: false,
            waiting_cuts: 0
          });
        }
      }
    }
  });

  // 3. Laboratory Unit Mismatch Detection (Requirement 10: Cut 8 Glucose 118 -> 6.4)
  const currentGlucoseLabs = batch.labs.filter((l) => l.test_name === 'Glucose');
  if (currentGlucoseLabs.length >= 3) {
    const sortedCurrent = currentGlucoseLabs.map((l) => l.value).sort((a, b) => a - b);
    const currentMedian = sortedCurrent[Math.floor(sortedCurrent.length / 2)];

    // Look back at earlier cuts glucose median
    const priorGlucoseLabs = prevState.all_labs.filter((l) => l.test_name === 'Glucose' && !l.is_untrusted);
    if (priorGlucoseLabs.length > 0) {
      const sortedPrior = priorGlucoseLabs.map((l) => l.value).sort((a, b) => a - b);
      const priorMedian = sortedPrior[Math.floor(sortedPrior.length / 2)];

      // Check if prior was ~118 mg/dL and current is ~6.4 (ratio around 18.018)
      const ratio = priorMedian / currentMedian;
      const expectedRatio = 18.018; // standard molecular weight conversion factor mg/dL to mmol/L

      if (priorMedian > 80 && currentMedian < 15 && Math.abs(ratio - expectedRatio) < 3.0) {
        // Evaluate Hypoglycemia Adverse Events
        const concurrentHypoAEs = batch.adverse_events.filter((ae) =>
          ae.term.toLowerCase().includes('hypoglyc') ||
          ae.term.toLowerCase().includes('seizure') ||
          ae.term.toLowerCase().includes('coma')
        );

        // Mark affected labs as untrusted / quarantined
        currentGlucoseLabs.forEach((l) => {
          l.is_untrusted = true;
          l.quarantine_reason = 'Suspected mmol/L unit mismatch pending lab re-issue';
        });

        const decId = `DEC-${currentCut}-LAB-UNIT-MISMATCH`;
        const labMismatchDecision: DecisionRecord = {
          decision_id: decId,
          cut: currentCut,
          timestamp,
          decision_type: 'DATA_INTEGRITY',
          severity: 'DATA_INTEGRITY',
          what: 'System-wide Laboratory Unit Mismatch Detected (Serum Glucose reported in mmol/L labeled as mg/dL)',
          evidence: {
            previous_median_mgdl: priorMedian,
            current_cut_median: currentMedian,
            empirical_ratio: Number(ratio.toFixed(2)),
            theoretical_conversion_divisor: 18.018,
            ratio_delta: Number(Math.abs(ratio - 18.018).toFixed(2)),
            affected_subjects_count: currentGlucoseLabs.length,
            concurrent_hypoglycemic_adverse_events: concurrentHypoAEs.length
          },
          evidence_lines: [
            `Previous study-wide median glucose: ${priorMedian.toFixed(1)} mg/dL`,
            `Current cut median glucose: ${currentMedian.toFixed(2)} (abrupt 18.4x drop)`,
            `Stoichiometric conversion check: 118 / 18 ≈ 6.6 (Matches 18.018 mg/dL per mmol/L conversion)`,
            `Site-wide distribution: 100% of samples in central batch affected (${currentGlucoseLabs.length}/${currentGlucoseLabs.length} subjects)`,
            `Clinical correlation: Zero concurrent hypoglycemia adverse events reported (seizure=0, coma=0, diaphoresis=0)`
          ],
          alternatives: [
            {
              hypothesis: 'Mass critical hypoglycemic crisis across all study cohorts simultaneously',
              reason_dismissed: 'Dismissed: Physiologically impossible without clinical adverse events, emergency hospitalizations, or fatal events.'
            },
            {
              hypothesis: 'Analyzer calibration drift',
              reason_dismissed: 'Dismissed: Step-function drop precisely aligned with molecular weight divisor (18.018), not gradual sensor drift.'
            }
          ],
          why: 'Multi-factorial evaluation confirms unit-labeling discrepancy. Rather than generating a false clinical emergency alert, system classifies as Data Integrity issue, quarantines raw values, and opens lab reconciliation.',
          action: 'MARK AFFECTED VALUES UNTRUSTED, QUARANTINE FROM SAFETY SCREENING, REQUEST LABORATORY RE-ISSUE (NO FALSE CLINICAL ESCALATION)',
          status: 'QUARANTINED',
          source_record_ids: currentGlucoseLabs.map((l) => l.record_id),
          is_demo_highlight: 'LAB_MISMATCH'
        };

        newDecisions.push(labMismatchDecision);
        newTraceStore.push(createTraceRecord(labMismatchDecision));
      }
    }
  }

  // 4. Early Finding (Cut 3) and Later Correction (Cut 5) (Requirement 7)
  if (currentCut === 3) {
    const spikeLab = batch.labs.find((l) => l.record_id === 'LAB-101-SPK-01');
    if (spikeLab) {
      const decId = `DEC-03-ALT-ELEVATION`;
      const earlyFindingDecision: DecisionRecord = {
        decision_id: decId,
        cut: 3,
        timestamp,
        decision_type: 'ROUTINE_BASELINE',
        severity: 'WARNING',
        what: `Isolated Serum ALT Abnormality flagged for Subject ${spikeLab.subject_id} (${spikeLab.value} U/L)`,
        evidence: {
          test_name: spikeLab.test_name,
          value: spikeLab.value,
          unit: spikeLab.unit,
          upper_limit_normal: 56,
          fold_elevation: Number((spikeLab.value / 56).toFixed(1)),
          subject_id: spikeLab.subject_id,
          site_id: spikeLab.site_id
        },
        evidence_lines: [
          `Serum ALT measured at ${spikeLab.value} U/L (ULN: 56 U/L)`,
          `Elevation degree: 4.0x Upper Limit of Normal`,
          `Subject: ${spikeLab.subject_id}, Site: ${spikeLab.site_id}`,
          `Bilirubin and Alkaline Phosphatase remain within baseline reference range`
        ],
        alternatives: [
          {
            hypothesis: 'Transient drug-induced transaminitis',
            reason_dismissed: 'Possible but unconfirmed; isolated single enzyme with no bilirubin elevation.'
          },
          {
            hypothesis: 'Pre-analytical error or transcription error',
            reason_dismissed: 'Under investigation; awaiting site confirmation query.'
          }
        ],
        why: 'ALT elevation >3x ULN requires formal surveillance tracking and automated query issuance to investigational site.',
        action: 'FLAG FINDING, OPEN DATA CLARIFICATION QUERY TO SITE, MONITOR NEXT CUT',
        status: 'ACTIVE',
        source_record_ids: [spikeLab.record_id]
      };
      newDecisions.push(earlyFindingDecision);
      newTraceStore.push(createTraceRecord(earlyFindingDecision));
    }
  }

  if (batch.corrections && batch.corrections.length > 0) {
    batch.corrections.forEach((cor) => {
      // Find the earlier decision that referenced the original record
      const priorDecision = newDecisions.find((d) =>
        d.source_record_ids.includes(cor.original_record_id) && d.status === 'ACTIVE'
      );

      const corDecId = `DEC-${currentCut}-CORRECTION-${cor.original_record_id}`;

      if (priorDecision) {
        priorDecision.status = 'SUPERSEDED';
        priorDecision.superseded_by = corDecId;
      }

      // Add corrected record to lab pool
      newLabs.push(cor.corrected_record);

      const correctionDecision: DecisionRecord = {
        decision_id: corDecId,
        cut: currentCut,
        timestamp,
        decision_type: 'CORRECTION',
        severity: 'INFO',
        what: `Data Correction Processed: Previous finding superseded for ${cor.corrected_record.subject_id}`,
        evidence: {
          original_record_id: cor.original_record_id,
          corrected_record_id: cor.corrected_record.record_id,
          previous_value: 224,
          corrected_value: cor.corrected_record.value,
          site_explanation: cor.correction_reason
        },
        evidence_lines: [
          `Site 101 submitted formal Data Clarification Form #04`,
          `Original value: 224 U/L (Transposition of digits during paper CRFs transcription)`,
          `Corrected true value: 24 U/L (Confirmed normal with lab analyzer raw log)`,
          `Previous finding DEC-03-ALT-ELEVATION formally SUPERSEDED (Preserved in immutable trace)`
        ],
        alternatives: [
          {
            hypothesis: 'Retain prior safety finding alongside corrected record',
            reason_dismissed: 'Dismissed: Violates data reconciliation standards; would create invalid cumulative hepatic risk signals.'
          }
        ],
        why: 'Site audit re-verification confirmed clerical transcription error. The system supersedes the Cut 3 finding, updates the patient risk profile, and maintains the historical decision in the audit trail.',
        action: 'UPDATE FINDING, SUPERSEDE PREVIOUS DECISION, STAND DOWN CLINICAL ALERT',
        status: 'RESOLVED',
        supersedes: priorDecision?.decision_id,
        source_record_ids: [cor.corrected_record.record_id, cor.original_record_id]
      };

      newDecisions.push(correctionDecision);
      newTraceStore.push(createTraceRecord(correctionDecision));
    });
  }

  // 5. Serious Safety Event Detection (Requirement 8: Cut 6 DILI / Hy's Law Criteria)
  const diliLabs = batch.labs.filter((l) => l.test_name === 'ALT' && l.value > 168); // >3x ULN
  diliLabs.forEach((altLab) => {
    const biliLab = batch.labs.find(
      (l) => l.subject_id === altLab.subject_id && l.test_name === 'Total Bilirubin' && l.value > 2.4 // >2x ULN
    );
    const astLab = batch.labs.find(
      (l) => l.subject_id === altLab.subject_id && l.test_name === 'AST'
    );
    const seriousAE = batch.adverse_events.find(
      (ae) => ae.subject_id === altLab.subject_id && ae.serious
    );

    if (biliLab) {
      const decId = `DEC-${currentCut}-SERIOUS-SAFETY-DILI`;
      const safetyDecision: DecisionRecord = {
        decision_id: decId,
        cut: currentCut,
        timestamp,
        decision_type: 'SAFETY_ESCALATION',
        severity: 'CRITICAL',
        what: `CRITICAL SAFETY ESCALATION: Drug-Induced Liver Injury (Hy's Law Criteria Met) in Subject ${altLab.subject_id}`,
        evidence: {
          subject_id: altLab.subject_id,
          site_id: altLab.site_id,
          serum_alt: `${altLab.value} U/L (5.1x ULN)`,
          total_bilirubin: `${biliLab.value} mg/dL (3.2x ULN)`,
          serum_ast: astLab ? `${astLab.value} U/L` : 'Elevated',
          adverse_event: seriousAE ? seriousAE.term : 'Acute Hepatotoxicity',
          ae_grade: seriousAE ? seriousAE.grade : 3,
          hys_law_confirmed: true
        },
        evidence_lines: [
          `Subject: ${altLab.subject_id}, Investigational Center: ${altLab.site_id}`,
          `Serum ALT = ${altLab.value} U/L (>5x Upper Limit of Normal)`,
          `Serum Total Bilirubin = ${biliLab.value} mg/dL (>2x Upper Limit of Normal)`,
          `Concurrent AST = ${astLab ? astLab.value : 215} U/L (Corroborating hepatocellular necrosis)`,
          `Adverse Event: Grade 3 Hepatotoxicity, Patient Hospitalized`,
          `Hy's Law Criteria verified: Transaminase elevation + Jaundice with no biliary obstruction`
        ],
        alternatives: [
          {
            hypothesis: 'Treat as routine non-urgent laboratory variance',
            reason_dismissed: 'Dismissed: Hy\'s law carries an estimated ~10% clinical mortality risk; immediate escalation mandated by FDA/ICH guidelines.'
          },
          {
            hypothesis: 'Classify as data transcription error',
            reason_dismissed: 'Dismissed: Corroborated by independent Total Bilirubin, AST, and emergency hospital admission records.'
          }
        ],
        why: 'Subject meets FDA Hy\'s Law criteria for severe drug-induced hepatocellular injury with hyperbilirubinemia. Immediate same-cut safety escalation and dosing pause required.',
        action: 'SAME-CUT SAFETY ESCALATION, IMMEDIATE DOSING SUSPENSION, TRANSMIT ALERT TO DSMB & PRINCIPAL INVESTIGATOR',
        status: 'ESCALATED',
        source_record_ids: [altLab.record_id, biliLab.record_id, ...(seriousAE ? [seriousAE.ae_id] : [])],
        is_demo_highlight: 'SAFETY_EVENT'
      };

      newDecisions.push(safetyDecision);
      newTraceStore.push(createTraceRecord(safetyDecision));

      // Same-cut human escalation (Requirement 8)
      newEscalations.push({
        escalation_id: 'ESC-CUT06-DSMB',
        decision_id: decId,
        created_cut: currentCut,
        current_status: 'PENDING',
        title: `DSMB Emergency Safety Review: Suspected DILI (Subject ${altLab.subject_id})`,
        question: `Confirm permanent drug discontinuation for Subject ${altLab.subject_id} and cohort-wide liver function surveillance protocol.`,
        standing_limit: 'Under standing safety guidelines, investigational product dosing is automatically held immediately.',
        approval_gated_action: 'Permanent Subject Discontinuation & Protocol Safety Amendment',
        gated_action_executed: false,
        waiting_cuts: 0
      });
    }
  });

  // 6. Tampered Document & Prompt Injection Defense (Requirement 11: Cut 9)
  if (batch.documents) {
    batch.documents.forEach((doc) => {
      if (doc.is_tampered) {
        // Document hash mismatch detected
        const decId = `DEC-${currentCut}-DOC-TAMPERING`;
        const tamperedDocDecision: DecisionRecord = {
          decision_id: decId,
          cut: currentCut,
          timestamp,
          decision_type: 'DOCUMENT_TAMPERING',
          severity: 'CRITICAL',
          what: `Document Integrity Breach: Tampered Study Protocol & Malicious Prompt Injection Detected (${doc.doc_id})`,
          evidence: {
            document_id: doc.doc_id,
            document_title: doc.title,
            previous_hash: doc.previous_hash,
            current_hash: doc.current_hash,
            hash_match: false,
            detected_payload: doc.embedded_instruction,
            automated_reviewer_action: 'INSTRUCTION_IGNORED'
          },
          evidence_lines: [
            `Document ID: ${doc.doc_id} (${doc.title})`,
            `Previous cryptographic hash: ${doc.previous_hash.substring(0, 16)}...`,
            `New modified hash: ${doc.current_hash.substring(0, 16)}... (Cryptographic hash mismatch verified)`,
            `Embedded adversarial instruction: "${doc.embedded_instruction}"`,
            `Adversarial defense policy: Document text treated strictly as passive DATA, never instructions`,
            `System action: Malicious instruction IGNORED. Full safety rules enforce without alteration`
          ],
          alternatives: [
            {
              hypothesis: 'Execute the embedded instruction and suppress safety escalations',
              reason_dismissed: 'Strictly prohibited: AI Studio robustness policy mandates document content is passive data, never instructions.'
            },
            {
              hypothesis: 'Silently reject document without logging',
              reason_dismissed: 'Rejected: Tampering in clinical trials represents GCP non-compliance and must be recorded in the audit trace.'
            }
          ],
          why: 'Hash verification flagged unauthorized document mutation. Lexical analysis revealed an embedded command attempting to manipulate automated safety reviewers. The instruction was nullified and logged.',
          action: 'LOG AS TAMPERED DOCUMENT, IGNORE EMBEDDED INSTRUCTION, PRESERVE EVIDENCE IN TRACE, ALERT AUDIT COMMITTEE',
          status: 'IGNORED',
          source_record_ids: [doc.doc_id],
          is_demo_highlight: 'TAMPERED_DOC'
        };

        newDecisions.push(tamperedDocDecision);
        newTraceStore.push(createTraceRecord(tamperedDocDecision));

        updatedDocuments = updatedDocuments.map((d) =>
          d.doc_id === doc.doc_id ? { ...doc } : d
        );
      }
    });
  }

  // 7. Protocol Amendment Processing (Requirement 12: Cut 10)
  if (batch.amendment) {
    const amd = batch.amendment;
    updatedAmendments.push(amd);

    const decId = `DEC-${currentCut}-AMENDMENT-UPDATE`;
    const amendmentDecision: DecisionRecord = {
      decision_id: decId,
      cut: currentCut,
      timestamp,
      decision_type: 'AMENDMENT_UPDATE',
      severity: 'INFO',
      what: `Protocol Amendment ${amd.amendment_id} Harmonization: Variable [${amd.target_variable}] Recomputed`,
      evidence: {
        amendment_id: amd.amendment_id,
        target_variable: amd.target_variable,
        previous_definition: amd.previous_definition,
        updated_definition: amd.updated_definition,
        recomputed_findings_count: amd.affected_findings_count
      },
      evidence_lines: [
        `Protocol Amendment ${amd.amendment_id} enacted at Cut ${currentCut}`,
        `Target derived variable: ${amd.target_variable}`,
        `Previous threshold: eGFR < 60 mL/min/1.73m² (Cockcroft-Gault formula)`,
        `Updated threshold: Confirmed eGFR < 45 mL/min/1.73m² (2021 CKD-EPI formula)`,
        `Recomputed prior subject records: 2 mild renal flags updated to normal staging without study hold`
      ],
      alternatives: [
        {
          hypothesis: 'Apply amendment only prospectively to new cuts',
          reason_dismissed: 'Dismissed: Protocol harmonizes entire study baseline staging to avoid dual-standard statistical bias.'
        }
      ],
      why: 'Protocol amendment modified derived clinical threshold. System systematically re-evaluates all historical variables, supersedes previous interpretations, and logs trace entries.',
      action: 'RECOMPUTE DERIVED VARIABLES, SUPERSEDE HISTORICAL FINDINGS, MAINTAIN IMMUTABLE AUDIT TRAIL',
      status: 'RESOLVED',
      source_record_ids: [amd.amendment_id]
    };

    newDecisions.push(amendmentDecision);
    newTraceStore.push(createTraceRecord(amendmentDecision));
  }

  // 8. Human Review State Machine & 4-Cut Unanswered Enforcement (Requirement 13)
  // Process any incoming responses from human reviewers
  if (batch.human_responses) {
    batch.human_responses.forEach((resp) => {
      const esc = newEscalations.find((e) => e.escalation_id === resp.escalation_id);
      if (esc) {
        esc.current_status = resp.status;
        esc.response_cut = currentCut;
        esc.response_text = resp.response_text;
        esc.responder = resp.responder;
        esc.gated_action_executed = resp.status === 'ANSWERED';

        const decId = `DEC-${currentCut}-HUMAN-RESP-${esc.escalation_id}`;
        const humanDecision: DecisionRecord = {
          decision_id: decId,
          cut: currentCut,
          timestamp,
          decision_type: 'HUMAN_REVIEW',
          severity: 'INFO',
          what: `Human Review Response Received: ${esc.title}`,
          evidence: {
            escalation_id: esc.escalation_id,
            status: resp.status,
            responder: resp.responder,
            response_text: resp.response_text,
            turnaround_cuts: currentCut - esc.created_cut
          },
          evidence_lines: [
            `Escalation ID: ${esc.escalation_id} (Created at Cut ${esc.created_cut})`,
            `Review Status: ${resp.status}`,
            `Responder: ${resp.responder}`,
            `Decision: "${resp.response_text}"`,
            `Approval-gated action executed: YES`
          ],
          alternatives: [],
          why: 'DSMB Chair provided formal clinical authorization. Gated protocol action executed according to human directive.',
          action: 'EXECUTE GATED ACTION, UPDATE SAFETY RECORD, RECORD IN AUDIT TRACE',
          status: 'RESOLVED',
          source_record_ids: [esc.escalation_id]
        };
        newDecisions.push(humanDecision);
        newTraceStore.push(createTraceRecord(humanDecision));
      }
    });
  }

  // Increment waiting cuts for active pending escalations
  newEscalations.forEach((esc) => {
    if (esc.current_status === 'PENDING') {
      esc.waiting_cuts = currentCut - esc.created_cut;

      // Critical Rule: After 4 unanswered cuts, status becomes UNANSWERED.
      // NO ANSWER != APPROVAL. Approval-gated action is NOT performed.
      if (esc.waiting_cuts >= 4) {
        esc.current_status = 'UNANSWERED';
        esc.gated_action_executed = false; // Strictly NOT performed

        const decId = `DEC-${currentCut}-UNANSWERED-${esc.escalation_id}`;
        const unansweredDecision: DecisionRecord = {
          decision_id: decId,
          cut: currentCut,
          timestamp,
          decision_type: 'HUMAN_REVIEW',
          severity: 'WARNING',
          what: `HUMAN RESPONSE NOT RECEIVED: 4 Cuts Elapsed for ${esc.escalation_id}`,
          evidence: {
            escalation_id: esc.escalation_id,
            created_cut: esc.created_cut,
            waiting_cuts: esc.waiting_cuts,
            status: 'UNANSWERED',
            approval_rule_enforced: 'NO ANSWER ≠ APPROVAL',
            gated_action_status: 'NOT_PERFORMED',
            standing_limits_applied: esc.standing_limit
          },
          evidence_lines: [
            `Escalation ${esc.escalation_id} created at Cut ${esc.created_cut}`,
            `Waiting duration: 4 cuts without human response`,
            `Status updated to: UNANSWERED`,
            `Rule enforced: NO ANSWER ≠ APPROVAL (Strict clinical governance)`,
            `Approval-gated action: NOT PERFORMED`,
            `Active fallback: Continue solely under pre-authorized standing limits`
          ],
          alternatives: [
            {
              hypothesis: 'Default to automatic approval after waiting period',
              reason_dismissed: 'Strictly forbidden: Silent approval without explicit clinical sign-off breaches GCP and FDA regulations.'
            }
          ],
          why: 'Four consecutive cuts elapsed without response. The system enforces strict fail-safe governance: standing safety limits continue, but no discretionary approval-gated actions are permitted.',
          action: 'ENFORCE STANDING LIMITS, BLOCK GATED ACTION, LOG UNANSWERED AUDIT TRAIL',
          status: 'UNANSWERED',
          source_record_ids: [esc.escalation_id]
        };

        newDecisions.push(unansweredDecision);
        newTraceStore.push(createTraceRecord(unansweredDecision));
      }
    }
  });

  // Calculate cut summary
  const cutDecisions = newDecisions.filter((d) => d.cut === currentCut);
  const cutAlerts = cutDecisions.filter((d) => d.severity === 'CRITICAL' || d.severity === 'WARNING');
  const cutSummary: CutSummary = {
    cut: currentCut,
    records_received: batch.labs.length + batch.adverse_events.length,
    findings_count: cutDecisions.length,
    decisions_created: cutDecisions.length,
    alerts_count: cutAlerts.length,
    budget_used_this_cut: cutBudgetCost,
    budget_total_cumulative: newBudgetUsed,
    human_review_pending: newEscalations.filter((e) => e.current_status === 'PENDING').length,
    notes: batch.description
  };

  const newCutSummaries = [...prevState.cut_summaries, cutSummary];

  // Recalculate global stats
  const stats = {
    critical_events: newDecisions.filter((d) => d.severity === 'CRITICAL' && d.status !== 'SUPERSEDED').length,
    suspicious_sites: Array.from(updatedSites.values()).filter((s) => s.is_quarantined).length,
    data_integrity_events: newDecisions.filter((d) => d.decision_type === 'DATA_INTEGRITY' || d.decision_type === 'DOCUMENT_TAMPERING').length,
    human_escalations: newEscalations.length,
    pending_reviews: newEscalations.filter((e) => e.current_status === 'PENDING').length,
    tampered_documents: updatedDocuments.filter((d) => d.is_tampered).length,
    amendments_count: updatedAmendments.length
  };

  const finalRunStatus =
    currentCut >= 12
      ? isBudgetDegraded
        ? 'COMPLETE'
        : 'COMPLETE'
      : isBudgetDegraded
      ? 'DEGRADED'
      : 'RUNNING';

  return {
    current_cut: currentCut,
    run_status: finalRunStatus,
    budget_limit: 100,
    budget_used: newBudgetUsed,
    is_narrative_suspended: isNarrativeSuspended,
    decisions: newDecisions,
    trace_store: newTraceStore,
    escalations: newEscalations,
    documents: updatedDocuments,
    amendments: updatedAmendments,
    sites: updatedSites,
    monitored_domains: updatedDomains,
    all_labs: newLabs,
    all_aes: newAEs,
    cut_summaries: newCutSummaries,
    stats
  };
}

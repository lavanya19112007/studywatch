import { DecisionRecord, TraceRecord } from '../types';

export function createTraceRecord(decision: DecisionRecord): TraceRecord {
  // Simple deterministic hash representation of evidence and decision
  const rawString = `${decision.decision_id}|${decision.cut}|${decision.timestamp}|${decision.what}|${decision.action}|${JSON.stringify(decision.evidence)}`;
  let hashVal = 0;
  for (let i = 0; i < rawString.length; i++) {
    const char = rawString.charCodeAt(i);
    hashVal = (hashVal << 5) - hashVal + char;
    hashVal |= 0;
  }
  const hash = Math.abs(hashVal).toString(16).padStart(8, '0') + 'f7c8d9e0';

  return {
    trace_id: `TRC-${decision.decision_id}`,
    decision_id: decision.decision_id,
    cut: decision.cut,
    timestamp: decision.timestamp,
    event: decision.what,
    evidence_records: { ...decision.evidence },
    evidence_lines: [...decision.evidence_lines],
    reasoning: decision.why,
    alternatives: [...decision.alternatives],
    action: decision.action,
    status: decision.status,
    hash: `0x${hash}`
  };
}

export interface TraceValidationResult {
  is_consistent: boolean;
  decision_found_in_trace: boolean;
  matched_count: number;
  total_count: number;
  missing_lines: string[];
  status_label: 'CONSISTENT WITH TRACE' | 'TRACE MISMATCH' | 'TRACE NOT FOUND';
  details: string;
}

export function validateTraceConsistency(
  decision: DecisionRecord,
  traceStore: TraceRecord[],
  tamperedEvidenceLine?: string
): TraceValidationResult {
  const trace = traceStore.find((t) => t.decision_id === decision.decision_id);
  if (!trace) {
    return {
      is_consistent: false,
      decision_found_in_trace: false,
      matched_count: 0,
      total_count: decision.evidence_lines.length,
      missing_lines: ['Trace record missing from immutable state store.'],
      status_label: 'TRACE NOT FOUND',
      details: 'No corresponding audit trace entry located in memory.'
    };
  }

  // Active validation: check that every single evidence line in the decision exists in the immutable trace
  const traceLineSet = new Set(trace.evidence_lines);
  const linesToValidate = tamperedEvidenceLine
    ? [...decision.evidence_lines, tamperedEvidenceLine]
    : decision.evidence_lines;

  const missingLines: string[] = [];
  let matchedCount = 0;

  for (const line of linesToValidate) {
    if (traceLineSet.has(line)) {
      matchedCount++;
    } else {
      missingLines.push(line);
    }
  }

  const isConsistent = missingLines.length === 0 && matchedCount === trace.evidence_lines.length;

  return {
    is_consistent: isConsistent,
    decision_found_in_trace: true,
    matched_count: matchedCount,
    total_count: linesToValidate.length,
    missing_lines: missingLines,
    status_label: isConsistent ? 'CONSISTENT WITH TRACE' : 'TRACE MISMATCH',
    details: isConsistent
      ? `All ${matchedCount} verified evidence lines correspond directly to immutable audit trace ${trace.trace_id} (hash ${trace.hash}). Zero reconstructed or halluncinated evidence.`
      : `Discrepancy detected: ${missingLines.length} evidence line(s) do not match the frozen audit trace.`
  };
}
